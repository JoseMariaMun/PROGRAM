package CentroSalud;

public class CitaMedico {
    //Atributos cita médico
    int dia, mes;
}
